<!doctype html>
<html>
<head>
<meta charset="utf-8">

<title>EMI Calculator</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<link href="https://fonts.googleapis.com/css?family=Cabin&display=swap" rel="stylesheet">
<!-- style -->
<style>
    form{
  color:gainsboro;
}
.calculator{
  
    background-image:  linear-gradient( rgba(0, 0, 0, 0.7),rgba(0, 0, 0, 0.5)), url("images/calculator.jpg");
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    height: 580px;
    margin-top:50px;
     padding-top: 9%;  
    background-attachment: fixed;
  }
  .invert{
    text-align: center;
    color: #ffffff;
  padding-top: 2%;
    font-weight: 900;
    font-size: 50px;
  }
  .invert1{
  padding-top: 25px; 
  }
  .invert2{
    padding: 25px;
  }
   .a h5{   
      background-color: gray;
      padding: 2px;
      text-align: center;
      letter-spacing: 5px;
      color:white;
  }

.bs{
margin-top: 9px;
background-color: #4fd2ab;
border: none;
border-radius: 2px;
color: white;
font-size: 25px;
font-weight: 600;
}




/ EMI calculator media query /

/ Extra small devices (portrait phones, less than 576px) /
@media (max-width: 575.98px) { 
    .calculator{
          height: 901px!important;
}
 }

/ Small devices (landscape phones, 576px and up) /
@media (min-width: 576px) and (max-width: 767.98px) {  }

/ Medium devices (tablets, 768px and up) /
@media (min-width: 768px) and (max-width: 991.98px) { 
    .bs{
padding:7px 30px!important;
}
.particular{
    word-spacing:-5px!important;
    letter-spacing: 0;
}
 }

/ Large devices (desktops, 992px and up) /
@media (min-width: 992px) and (max-width: 1199.98px) {
    .bs{
padding:7px 30px!important;
}
  }

/ Extra large devices (large desktops, 1200px and up) /
@media (min-width: 1200px) {  }


</style>
</head>

 <body>
   <section class="calculator">
                <div class="overlay">
                    <div class="container">
                  <div class="a col-sm-6 col-md-3">
              <h5 >CALCULATOR</h5>
            </div>
        </div>
          <div class="container elementor-background-overlay">
              <h1 class="invert " style="font-family: 'Cabin', sans-serif;">My Monthly Payment</h1>
              <form>
                <div class="row invert1">
                    <div class="col-sm-12 col-md-3"> 
                <div class="form-group ">
                    <label for="usr">Loan Amount</label>
                    <input type="text" class="form-control invert2" id="prncipleAmount"  name="prncipleAmount" placeholder="Enter Amount" required>
                </div>
              </div>
              <div class="col-sm-12 col-md-3"> 
                <div class="form-group">
                    <label for="usr">Interest Rate %</label>
                    <input type="text" class="form-control invert2" id="InterestRate" name="InterestRate" placeholder="enter Rate of interest" required>
                </div>
                </div>
                <div class="col-sm-12 col-md-3"> 
                <div class="form-group">
                <label for="usr" class="particular">Loan Period (in month)</label>
                <input type="text" class="form-control invert2" id="emiMonth" name="emiMonth" placeholder="enrer in month" required>
                </div>
                </div>
                <div class="col-sm-12 col-md-3"> 
                <div class="form-group">
                    <label for="usr"></label><br>
                    <button type="button" onclick="EmiCalculaor();" class="bs">Calculate</button>
              </div>
              </div>
                </div>
              <div class="row" >
                  <div class="col-md-3 col-sm-12">
                      <label for="usr">Total Payment</label>
                      <input type="text" class="form-control invert2" id="result">
                    </div>
                    <div class="col-md-9 col-sm-12">
                        <label for="usr"></label><br>
                    <p ><img src="images/warning.png" width="28px">       Results are based solely on the information you have provided; product may not be available for all terms entered. These calculations are provided for illustrative purposes only and do not reflect any closing costs or down payment.</p>
                   
                     
                        </div>
                        
                    </div>
                  </form>
           
           </div>
          </div>
          </section>

<!-- script for calculating EMI -->
<!-- script for calculating EMI -->
<script>
        function EmiCalculaor(){
            
            
          var month = $("#emiMonth").val();
          var rate = $("#InterestRate").val();
          var pamt = $("#prncipleAmount").val();
          
           var monthlyInterestRatio = (rate/100)/12;
           var monthlyInterest = (monthlyInterestRatio*pamt);
              var top = Math.pow((1+monthlyInterestRatio),month);
                 var bottom = top -1;
                 var sp = top / bottom;
                 var emi = ((pamt  monthlyInterestRatio)  sp);
           var result = emi.toFixed(2);
           var totalAmount = emi*month;
           var yearlyInteret = totalAmount-pamt;
           var downPayment = pamt*(20/100);
              //alert(emi);
           $("#result").empty();
          //  $("#result").append("Your EMI = "+result);
            document.getElementById("result").value=result;
        }
        </script>
</body>
</html>



