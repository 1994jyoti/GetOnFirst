<!DOCTYPE html>
<html lang="en">
  <head>
  	<title>bookMyPersonalLoan | axisBankPersonalLoan</title>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


<link href="https://fonts.googleapis.com/css?family=Cabin&display=swap" rel="stylesheet">
<link rel="stylesheet" href="Link/mdb.min.css">
<link rel="stylesheet" href="axisbank.css">

  </head>
  <body>
  	
  	<section id="section1">
       
            <div class="bg-img">
               <div class="title">
                   <h1>AXIS Bank Personal Loan</h1>
                   <a href="#">Home</a><span> / </span><span class="activePage">AXIS Bank Personal Loan</span>
               </div> 
            </div>
       
    </section>
    <div class="container-fluid">
    <div class=" row space">
    	<div class="col-sm-12 col-md-8 col-lg-8">
    	<h3 class="text-center" style="color: #fff;">Apply for Personal Loan.</h3>
    	</div>
    	<div class="col-sm-12 col-md-4 col-lg-4 contact">
    	 <section class="subbtn">
  <a href="#apply">Submit</a>
  
  </section>
    </div>
</div><!--row close-->
 </div>

<div class="container-fluid">
  	<div class="row">
  	<div class="col-sm-12 col-md-6 col-lg-6 fRow"> 
  		<h2 style="color: #ffbb38;">About AXIS Bank Personal Loan Bangalore</h2>
  		<div class="line"></div>
  	<p class="pera" style="color: #fff; text-align: justify;"> 
  		Easy Way to Get the Personal Loan in Bangalore from Axis Bank. Axis Bank is the third largest bank in India, there are providing Personal Loan for pocket friendly rate compared to competitors or other banks. Axis bank major benefits include Pre-Closure, Partial Payment and Flexible repayment options. Apply for Axis bank personal loan in Bangalore and fulfill your requirement with minimum documentation. Check Personalloanemi calculator helps you to select monthly email as per your convenience.<br>

Axis Bank are providing special corporate offers for personal loan in Bangalore. Axis Bank Personal loan facilitates flexible monthly installment, and requires very simple documentation, compared to other loan. Axis bank provides personal loan up to Rs. 25Lakhs*with interest rates ranging from 13.5%* to 24%. Tenure Available in Axis bank Minimum 12 months, Maximum 60 months. There are no Pre-closure charges and Prepayment charges and it allows easy transfer of personal loan with other Banks through its balance transfer facility.<br>

A Personal loan from Axis bank is very simple, Approval within 24 hours*, Disbursement within 48 Hours*. Axis Bank considers 50-70% of your monthly net take home as EMI option, so you will be eligible for the most amount of loan. Axis Bank Provides Personal Loan with Maximum Eligibility according to your salary.</p>
  		</div>
  		<div class="col-sm-12 col-md-6 col-lg-6 fImg">
  			  		</div>
  	</div><!--row colse-->
  </div>


<div class="container-fluid">
  	<div class="row">
  		  		<div  class="col-sm-12 col-md-6 col-lg-6 Img2">

  		  		</div>
  		<div  class=" sRow col-sm-12 col-md-6 col-lg-6">
  			<h2 style="color: #003679;" >Existing Corporate offer on Personal Loan Axis Bank in Bangalore</h2>
  			<div class="line"></div>
  			<p style="text-align: justify;">  			
  			Personal loan Axis bank in bangalore provides corporate rates for salary account holders. If your monthly salary package exceeds 75k* Loan will be dispersed within 24 hours* with Lowest processing fee and Lowest interest Rate. For Top most corporate companies ROI Minimum 13.5%* onwards (T&C Apply).
         <h3 style="color: #003679;"> AXIS Bank Personal Loan Bangalore</h3>
         AXIS Bank is provides the best loan service in bangalore. Different type of Loan available at AXIS Bank includes Personal Loans, Marriage Loan, Home Loan, Travel Loans, Mortgage Loan, Business Loans, Medical Loan, Education Loan and House Construction loan.<br>
         <br>
        <b style="color: black;"> Bookmypersonalloan.com (us) has Coordinated with AXIS Bank for its Services like Home Loan, Mortgage Loan, Car Loan and Education Loan. Individuals seeking AXIS Bank Personal Loan in Bangalore can avail Services from us to get Quick and hassle free Loan.</b><br>
        <ul><li>Very Si Paperwork support: We are providing door step service 365 days and 24/7 to the loan seeker by collecting the documents for them and submitting it to the Bank. The users need not worry about the paperwork and other documentation process of Axis bank personal loan.</li>
        <li>Approval Timing: We are in the personal loan department in Bangalore and serve you to get loan approved within few minutes by AXIS Bank Bangalore.</li>
      <li>Advising best services: We assist the Loan seeker to choose the best deal available with AXIS bank personal loan. We also provide the complete details about the Highest Loan Eligibility criteria Provided by the Bank, as per the requirements of the Loan seeker.</li>
    </ul>
  		</p>
  			
  		</div>

  	</div><!--row div close hear-->
  </div>
<!--
<div class="container-fluid">
  	<div class="row">
  		  		<div  class=" tRow col-sm-12 col-md-6 col-lg-6">
  		  			<h2 style="color: #ffbb38;">Eligibility to Apply Axis Bank Personal Loan Bangalore</h2>

  			<div class="line"></div>
  		  			<p class="pera" style="text-align: justify;">  		  				
  		  				<ul><li>Minimum Salary 15,000 Required.</li>
                <li>If you have a Salary account with AXIS Bank, minimum salary should be 15,000.</li>
              <li>Even if you are not having Salary account with AXIS Bank, minimum salary should be 15,000.</li>
            <li>Minimum age required 21 years and maximum age is 60 years.
</li>
<li>If you completed 1 Month only in current company, even then also Loan will be Possible.</li>
<li>If your Total work Experience is 1 year only, you can get the Loan.</li>
<li>If you are staying in Bangalore Rented House or Own House, you can get the Loan</li>
<li>Unsecured Personal Loan Minimum Salary 15,000 Required.
</li>

</ul>
  		  			</p>
  			  		</div>
  		<div  class=" Img3 col-sm-12 col-md-6 col-lg-6">
  		</div>
  	</div>
  </div>-->

  	<div class="container-fluid">
  	<div class="row">
  		  		
  		<div  class="row4 col-sm-12 col-md-6 col-lg-6">
  			<h2 style="color: #ffbb38;">Axis Bank Personal Loan For Different Profiles</h2>
        			<div class="line"></div>
  			<p class="pera" style="text-align: justify;">
  				<ul>
        <li>If you are staying in paying Guest also Providing Personal Loan</li>
        <li>If you have Only 12 months work Experience we Provide Personal Loan.</li>  
        <li>If you have Only 12 months work Experience we Provide Personal Loan.</li>
        <li>If you have no Loan and no Card also get the Personal Loan.</li> 
        <li>You are not AXIS account Holder also Provide Personal Loan.</li>
        <li>For Doctors Personal Loans are Available.</li>   
        <li>For Professionals also we provide the Personal Loans.</li>
        <li>For Government Employees also we will give Personal Loan.</li> 
        <li>For Self-Employed also.</li> 
        <li>For teachers and lecturers also we Provide Personal Loan.</li>
        <li>Unsecured Personal Loan.</li> 
          </ul>
  				  			</p>
  		</div>
      <div  class="Img4 col-sm-12 col-md-6 col-lg-6">
<section class="cal3Dbtn">
 <div href="#calculate" class="calemibtn">Calculate EMI</div>
 </section>
      </div>
  	</div><!--row close-->
  </div>

<div class="container-fluid">
  	<div class="row">
  		   		<div  class="col-sm-12 col-md-6 col-lg-6">
  			<div class="applyForLoan" id="apply">
 <div class="formHeading">
  			<h4 class="text-center">Apply Axis Bank Personal Loan</h4>
  			</div>
                    <!-- Material input -->
        <div class="md-form">
            <input type="text" required id="form1" class="form-control">
                <label for="form1">Name</label>
                    </div>
         <div class="md-form">
               <input type="text" required id="form2" class="form-control">
                   <label for="form1">Mobile No</label>
                          </div>
             <div class="md-form">
                <input type="email" required id="form3" class="form-control">
						<label for="form1">Email ID</label>
                             </div>
          <div class="md-form">
                <input type="text" required id="form4" class="form-control">
                    <label for="form1">Min Salary</label>
                       </div>
            <div class="md-form">
               <input type="text" required id="form5" class="form-control">
                    <label for="form1">Expected Loan Amount</label>
                      </div>
            <div class="md-form">
               <input type="text" required id="form6" class="form-control">
                     <label for="form1">Net Salary Per Month</label>
                           </div>
            <div class="md-form">
                <input type="text" id="form7" class="form-control">
                    <label for="form1">Your Company Name</label>
                        </div>
            <div class="g-recaptcha" data-sitekey="6Ldbdg0TAAAAAI7KAf72Q6uagbWzWecTeBWmrCpJ"></div><br>
                <button type="submit" class="btn btn-primary text-center">Submit</button>                      
            
  		</div>
    </div>
  

          <div class="row5 col-sm-12 col-md-6 col-lg-6" style="background-color: #ffbb38;">
              <h2 style="color: #003679;">Eligibility to Apply Axis Bank Personal Loan Bangalore</h2>

        <div class="line"></div>
              <p class="pera" style="text-align: justify;">               
                <ul><li>Minimum Salary 15,000 Required.</li>
                <li>If you have a Salary account with AXIS Bank, minimum salary should be 15,000.</li>
              <li>Even if you are not having Salary account with AXIS Bank, minimum salary should be 15,000.</li>
            <li>Minimum age required 21 years and maximum age is 60 years.
</li>
<li>If you completed 1 Month only in current company, even then also Loan will be Possible.</li>
<li>If your Total work Experience is 1 year only, you can get the Loan.</li>
<li>If you are staying in Bangalore Rented House or Own House, you can get the Loan</li>
<li>Unsecured Personal Loan Minimum Salary 15,000 Required.
</li>

</ul>
              </p>
    
              <h2 style="color: #003679;">Documents Required to Process Axis Bank Personal Loan Bangalore</h2>
              <div class="line"></div>
              <p class="pera" style="text-align: justify;">
                
                <ul>
                  <li>Latest 3 Months Salary Slips.</li>
                  <li>Latest 3 Months Salary Credit Bank Statement.</li>
                  <li>Company ID card front and Bank.</li>
                  <li>Pan Card front and back (Photo clear copy).</li>
                  <li>Present Address proof.</li>
                  <li>Permanent Address proof.</li>
                  <li>Date of joining proof on Present Company.</li>
                  <li>Passport size photo 1.</li>
                  <li>Signature Proof Required as Per Bank.</li>
                  
                </ul>

              </p>
        
      </div>
  		</div> <!--row close-->
  	</div><!---->



  		<!-- EMI calculator code start-->
  <section class="calculator" id="calculate">
                <div class="overlay">
                    <div class="container">
                  <div class="calH col-sm-6 col-md-3">
              <h6 >CALCULATOR</h6>
            </div>
        </div>
          <div class="container elementor-background-overlay">
              <h1 class="invert " style="font-family: 'Cabin', sans-serif;">My Monthly Payment</h1>
              <form class="form2">
                <div class="row invert1">
                    <div class="col-sm-12 col-md-3"> 
                <div class="form-group ">
                    <label for="usr">Loan Amount</label>
                    <input type="text" class="form-control invert2" id="prncipleAmount"  name="prncipleAmount" placeholder="Enter amount" required>
                </div>
              </div>
              <div class="col-sm-12 col-md-3"> 
                <div class="form-group">
                    <label for="usr">Interest Rate %</label>
                    <input type="text" class="form-control invert2" id="InterestRate" name="InterestRate" placeholder="Enter rate of interest" required>
                </div>
                </div>
                <div class="col-sm-12 col-md-3"> 
                <div class="form-group">
                <label for="usr" class="particular">Loan Period (in month)</label>
                <input type="text" class="form-control invert2" id="emiMonth" name="emiMonth" placeholder="Enter (in month) " required>
                </div>
                </div>
                <div class="col-sm-12 col-md-3"> 
                <div class="form-group">
                    <label for="usr"></label><br>
                    <button type="button" onclick="EmiCalculaor();" class="calbtn" style="background-color: #4fd2ab;">Calculate</button>
              </div>
              </div>
                </div>
              <div class="row" >
                  <div class="col-md-3 col-sm-12">
                      <label for="usr">Total Payment</label>
                      <input type="text" class="form-control invert2" id="result" placeholder="Total">
                    </div>
                    <div class="col-md-9 col-sm-12">
                        <label for="usr"></label><br>
                    <p ><img src="images/warning.png" width="28px">       Results are based solely on the information you have provided; product may not be available for all terms entered. These calculations are provided for illustrative purposes only and do not reflect any closing costs or down payment.</p>
                   
                     
                        </div>
                        
                    </div>
                  </form>
           
           </div>
          </div>
          </section>


<!-- script for calculating EMI -->

<!--js-->
<!-- script for calculating EMI -->
<script>
        function EmiCalculaor(){
            
            
          var month = $("#emiMonth").val();
          var rate = $("#InterestRate").val();
          var pamt = $("#prncipleAmount").val();
          
           var monthlyInterestRatio = (rate/100)/12;
           var monthlyInterest = (monthlyInterestRatio*pamt);
              var top = Math.pow((1+monthlyInterestRatio),month);
                 var bottom = top -1;
                 var sp = top / bottom;
                 var emi = ((pamt  monthlyInterestRatio)  sp);
           var result = emi.toFixed(2);
           var totalAmount = emi*month;
           var yearlyInteret = totalAmount-pamt;
           var downPayment = pamt*(20/100);
              //alert(emi);
           $("#result").empty();
          //  $("#result").append("Your EMI = "+result);
            document.getElementById("result").value=result;
        }
        </script>
 <script src='https://www.google.com/recaptcha/api.js'></script>
  	<script src="Link/mdb.min.js"></script>
  </body>
</html>