<!DOCTYPE html>
<html lang="en">
  <head>
  	<title>bookMyPersonalLoan | Edel-Bank-Personal-Loan</title>
    <meta charset="utf-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


<link href="https://fonts.googleapis.com/css?family=Cabin&display=swap" rel="stylesheet">
<link rel="stylesheet" href="Link/mdb.min.css">
<link rel="stylesheet" href="edelbank.css">

  </head>
  <body>
  	
  	<section id="section1">
       
            <div class="bg-img">
               <div class="title">
                   <h1>Edel Bank Personal Loan</h1>
                   <a href="#">Home</a><span> / </span><span class="activePage">Edel Bank Personal Loan</span>
               </div> 
            </div>
       
    </section>
    <div class="container-fluid">
    <div class=" row space">
    	<div class="col-sm-12 col-md-8 col-lg-8">
    	<h3 class="text-center" style="color: #fff;">Apply for Personal Loan.</h3>
    	</div>
    	<div class="col-sm-12 col-md-4 col-lg-4 contact">
    	<section class="subbtn">
  <a href="#apply">Submit</a>
  
  </section>
    </div>
</div><!--row close-->
 </div>

<div class="container-fluid">
  	<div class="row">
  	<div class="col-sm-12 col-md-6 col-lg-6 fRow"> 
  		<h2 style="color: #ffbb38;">Edel Bank Personal loan in Bangalore</h2>
  		<div class="line"></div>
  	<p class="pera" style="color: #fff; text-align: justify;"> 
  		HDFC Bank is considered as second largest banking and financial service companies in India. HDFC bank is a leading in providing personal loan with lowest interest rate, instant and quick approval. Get HDFC Bank Personal Loan in Bangalore and fulfill your requirement with minimum Documentation. Check your Best monthly Installment in PersonalLoanEmi Calculator and select your EMI as per your convenience.<br>

HDFC Bank provides an exciting offer on Personal Loan for the salary account holders.

The HDFC Bank Offer Loans ranging from Rs.50, 000/- to Rs. 30 Lakhs for both Salaried as well as Self Employes. The Interest Rates ranges from 11.49%-18.75% with maximum Tenure of 60 months. Processing fee starts from Rs.999 up to 2.5%* based on your eligibility.</p>
  		</div>
  		<div class="col-sm-12 col-md-6 col-lg-6 fImg">
  			  		</div>
  	</div><!--row colse-->
  </div>


<div class="container-fluid">
  	<div class="row">
  		  		<div  class="col-sm-12 col-md-6 col-lg-6 Img2">

  			
  		</div>
  		<div  class=" sRow col-sm-12 col-md-6 col-lg-6">
  			<h2 style="color: #003679;" >Existing Corporate Offer by Edel Bank on Personal Loan in Bangalore</h2>
  			<div class="line"></div>
  			<p style="text-align: justify;">  			
  			<ul>
  				<li>HDFC Bank is providing Special Offer on Personal Loans in Bangalore for Women Employees in more than 100 Locations within Bangalore.</li>
  				<li>Borrowers in Bangalore receive Personal Accidental Benefits and Accidental hospitalization Expenses as well as they cover critical illness (T&C Apply).</li>
  				<li>Facilitates Special Corporate offers lowest interest rates with Low charges for HDFC Bank Account Holders in Bangalore.</li>
  				<li>HDFC Bank Provides Personal Loan to First Time Borrower also in Bangalore.</li>
  				<li>HDFC bank grants Personal Loan in Bangalore on the Basis of Credit Transactions on your Credit Card or Home Loan, Car Loan, Mortgage Loan, Education Loan and Personal Loan.(On Basis of your repayment track)</li>
  				<li>HDFC Bank Bangalore has a 24/7 Customer Support helpline. The Customers can contact the Bank through SMS, web chat, click2talk and phone banking. This helps customers to resolve their queries and resolve issues within less time.</li>

  			</ul>
  		</p>
  			
  		</div>

  	</div><!--row div close hear-->
  </div>

<div class="container-fluid">
  	<div class="row">
  		  		<div  class=" tRow col-sm-12 col-md-6 col-lg-6">
  		  			<h2 style="color: #ffbb38;">Edel Bank Personal Loan Bangalore</h2>

  			<div class="line"></div>
  		  			<p 0class="pera" style="text-align: justify;">  		  				
  		  				<h5 style="color: skyblue;">HDFC Bank is Providing Best Loan Service. Different type of loan available at HDFC Bank are Personal Loans, Marriage Loans, Renovation Loans, Travel Loans, Mortgage Loans, Business Loans, Medical  Loan, Education  Loan and House Construction Loan.</h5><br>
  		  				Bookmypersonalloan (we) has Coordinated with HDFC Bank for its Services like Home Loan, Mortgage Loan, Car Loan and Education Loan. Individuals seeking Personal Loan in Bangalore from HDFC Bank can avail Services from us to get Quick and hassle free Loan.<br><br>
  		  				<ul>
  		  					<li>Bookmypersonalloan.com provides door step service for 365 Days and 24/7 to the Loan seeker. The users need not to worry about the paperwork and other documentation process of Personal Loan HDFC Bank Bangalore.</li>
  		  						<li>High-Speed Approval: We are in Personal Loan Department in Bangalore and serve you to Get your Loan Approved within few minutes by HDFC Bank Bangalore.</li>
  		  							<li>Advising best services: We are at Personal Loan Bangalore also help the Loan seeker to choose the Best Deal Available with HDFC bank according to the Highest Loan Eligibility criteria Provided by the Bank and the requirements of the Loan seeker.</li>
  		  				</ul>
  		  			</p>
  			
  		</div>
  		<div  class=" Img3 col-sm-12 col-md-6 col-lg-6">
  		</div>
  	</div><!--row is close-->
  </div>

  	<div class="container-fluid">
  	<div class="row">
  		  		<div  class="Img4 col-sm-12 col-md-6 col-lg-6">
<section class="cal3Dbtn">
 <div href="#calculate" class="calemibtn">Calculate EMI</div>
 </section>
  		</div>
  		<div  class="row4 col-sm-12 col-md-6 col-lg-6">
  			<h2 style="color: #003679;">Eligibility to Edel Bank Personal Loan Bangalore</h2>
  			<div class="line"></div>
  			<p class="pera" style="text-align: justify;">
  				
  				<ul>
  					<li>Minimum Salary 15,000 Required.</li>
  					<li>If you are having Salary account with HDFC Bank, minimum salary should be 15,000.</li>
  					<li>If you are not having Salary account with HDFC Bank, minimum salary should be 15,000.</li>
  					<li>Minimum Age required 21 years and maximum age is 60 years.</li>
  					<li>If you completed 1 Month only in current company, Loan will be Possible.</li>
  					<li>If your Total work Experience is 1 year only, you can get the Loan</li>
  					<li>If you are staying in Bangalore Rented House or Own House, you can get the Loan</li>
  					<li>Should be a Graduate.</li>
  					<li>If you are working in not Listed Company, then 3 years work Experience proof is mandatory.</li>
  					<li>If you are working in not Listed Company, then Salary 40,000 Required.</li>
  				</ul>
  			</p>
  		</div>
  	</div><!--row close-->
  </div>

<div class="container-fluid">
  	<div class="row">
  		  		<div class="row5 col-sm-12 col-md-6 col-lg-6 ">
  		  			<h2 style="color: #ffbb38;">Edel Bank Personal Loan For Different Profiles</h2>
  		  			<div class="line"></div>
  		  			<p class="pera" style="text-align: justify;">
  		  				
  		  				<ul>
  		  					<li>If you are staying in paying Guest also Providing Personal Loan.</li>
  		  					<li>If you are Having Only 6 months Experience also Provide a Personal Loan.</li>
  		  					<li>If you are the First Time Borrower also Provide Personal Loan.</li>
  		  					<li>If you have no Loan and no Card also get the Personal Loan.</li>
  		  					<li>You are not HDFC account Holder also Providing Personal Loan.</li>
  		  					<li>For Doctors also Personal Loans Available.</li>
  		  					<li>For Professionals also we provide the Personal Loans.</li>
  		  					<li>For Government Employees also we will give Personal Loan.</li>
  		  					<li>For Self-Employed also.</li>
  		  					<li>For teachers and lecturers also we Provide Personal Loan.</li>
  		  					<li>Unsecured Personal Loan in bangalore</li>
  		  				</ul>
  		  	<h2 style="color: #ffbb38;">Documents required to process Edel Bank Personal Loan Bangalore</h2>
  		  	<ul>
  		  		<li>Latest 3 Months Salary Slips</li>
  		  		<li>Latest 3 Months Salary Credit Bank Statement.</li>
  		  		<li>Company ID card front and Bank.</li>
  		  		<li>Pan Card front and back(Photo clear copy).</li>
  		  		<li>Present Address proof.</li>
  		  		<li>Permanent Address proof.</li>
  		  		<li>Date of joining proof on Present Company.</li>
  		  		<li>Passport size photo 1.</li>
  		  		<li>Signature Proof Required as Per Bank.</li>
  		  	</ul>			
  		  			</p>
  			
  		</div>
  		<div  class="col-sm-12 col-md-6 col-lg-6">
  			<div class="applyForLoan" id="apply">
 <div class="formHeading">
  			<h4 class="text-center">Apply Edel Bank Personal Loan</h4>
  			</div>
                    <!-- Material input -->
        <div class="md-form">
            <input type="text" required id="form1" class="form-control">
                <label for="form1">Name</label>
                    </div>
         <div class="md-form">
               <input type="text" required id="form2" class="form-control">
                   <label for="form1">Mobile No</label>
                          </div>
             <div class="md-form">
                <input type="email" required id="form3" class="form-control">
						<label for="form1">Email ID</label>
                             </div>
          <div class="md-form">
                <input type="text" required id="form4" class="form-control">
                    <label for="form1">Min Salary</label>
                       </div>
            <div class="md-form">
               <input type="text" required id="form5" class="form-control">
                    <label for="form1">Expected Loan Amount</label>
                      </div>
            <div class="md-form">
               <input type="text" required id="form6" class="form-control">
                     <label for="form1">Net Salary Per Month</label>
                           </div>
            <div class="md-form">
                <input type="text" id="form7" class="form-control">
                    <label for="form1">Your Company Name</label>
                        </div>
            <div class="g-recaptcha" data-sitekey="6Ldbdg0TAAAAAI7KAf72Q6uagbWzWecTeBWmrCpJ"></div><br>
                <button type="submit" class="btn btn-primary text-center">Submit</button>                      
            
  		</div></div>
  		</div> <!--row close-->
  	</div><!---->

  		<!-- EMI calculator code start-->
  <section class="calculator" id="calculate">
                <div class="overlay">
                    <div class="container">
                  <div class="calH col-sm-6 col-md-3">
              <h6 >CALCULATOR</h6>
            </div>
        </div>
          <div class="container elementor-background-overlay">
              <h1 class="invert " style="font-family: 'Cabin', sans-serif;">My Monthly Payment</h1>
              <form class="form2">
                <div class="row invert1">
                    <div class="col-sm-12 col-md-3"> 
                <div class="form-group ">
                    <label for="usr">Loan Amount</label>
                    <input type="text" class="form-control invert2" id="prncipleAmount"  name="prncipleAmount" placeholder="Enter amount" required>
                </div>
              </div>
              <div class="col-sm-12 col-md-3"> 
                <div class="form-group">
                    <label for="usr">Interest Rate %</label>
                    <input type="text" class="form-control invert2" id="InterestRate" name="InterestRate" placeholder="Enter rate of interest" required>
                </div>
                </div>
                <div class="col-sm-12 col-md-3"> 
                <div class="form-group">
                <label for="usr" class="particular">Loan Period (in month)</label>
                <input type="text" class="form-control invert2" id="emiMonth" name="emiMonth" placeholder="Enter (in month) " required>
                </div>
                </div>
                <div class="col-sm-12 col-md-3"> 
                <div class="form-group">
                    <label for="usr"></label><br>
                    <button type="button" onclick="EmiCalculaor();" class="calbtn" style="background-color: #4fd2ab;">Calculate</button>
              </div>
              </div>
                </div>
              <div class="row" >
                  <div class="col-md-3 col-sm-12">
                      <label for="usr">Total Payment</label>
                      <input type="text" class="form-control invert2" id="result" placeholder="Total">
                    </div>
                    <div class="col-md-9 col-sm-12">
                        <label for="usr"></label><br>
                    <p ><img src="images/warning.png" width="28px">       Results are based solely on the information you have provided; product may not be available for all terms entered. These calculations are provided for illustrative purposes only and do not reflect any closing costs or down payment.</p>
                   
                     
                        </div>
                        
                    </div>
                  </form>
           
           </div>
          </div>
          </section>


<!-- script for calculating EMI -->

<!--js-->
<!-- script for calculating EMI -->
<script>
        function EmiCalculaor(){
            
            
          var month = $("#emiMonth").val();
          var rate = $("#InterestRate").val();
          var pamt = $("#prncipleAmount").val();
          
           var monthlyInterestRatio = (rate/100)/12;
           var monthlyInterest = (monthlyInterestRatio*pamt);
              var top = Math.pow((1+monthlyInterestRatio),month);
                 var bottom = top -1;
                 var sp = top / bottom;
                 var emi = ((pamt  monthlyInterestRatio)  sp);
           var result = emi.toFixed(2);
           var totalAmount = emi*month;
           var yearlyInteret = totalAmount-pamt;
           var downPayment = pamt*(20/100);
              //alert(emi);
           $("#result").empty();
          //  $("#result").append("Your EMI = "+result);
            document.getElementById("result").value=result;
        }
        </script>
 <script src='https://www.google.com/recaptcha/api.js'></script>
  	<script src="Link/mdb.min.js"></script>
  </body>
</html>